""" 

Author: Scott Urbanski
Date Written: 07/12/24
Assignment: Modulus Sound Machine
Description: In this program the user is able to select a musical
             instrument from a group of radio buttons. The user can then
             press the record button which outputs the instrument choice
             to a text file. Finally, the user can press keys on a numpad
             which will output a numerical midi value to the text file.

"""




from tkinter import *
from breezypythongui import EasyFrame


class ModulusSoundMachine(EasyFrame):

    def __init__(self):

        self.file = open("Desktop\\midiNotes.txt", 'w')
        self.text = ""
           
        EasyFrame.__init__(self, width=250, height=200)
        self.setTitle("Modulus Sound Machine")
        self.setBackground("White")
        self.group = self.addRadiobuttonGroup(row=1,column=0,rowspan=4)
        defaultRB = self.group.addRadiobutton(text="Piano")
        self.group.setSelectedButton(defaultRB)
        self.group.addRadiobutton(text="Guitar")
        self.group.addRadiobutton(text="Trumpet")
        self.group.addRadiobutton(text="Cowbell")
        self.addLabel(text="Octave", row=1, column=4, sticky="WN", background="White", foreground="Black")

        buttonPanel = self.addPanel(row=5, column=0, columnspan= 5, background="gray")
        self.record = buttonPanel.addButton(text="Record", row=5,column=0, command=self.Record)
        self.stopRecording = buttonPanel.addButton(text="Stop Recording", row=5, column=1, state="disabled", command=self.StopRecording)
        buttonPanel.addButton(text="Quit", row=5,column=2, command=lambda: quit(None))
        self.addLabel(text="Soundwaves", row=0,column=1,columnspan=2, sticky="WE")
        self.octave = self.addIntegerField(row=2, column = 4, value=0, sticky="WN")

        keys = Toplevel()

        CALCULATOR_WIDTH = 260
        CALCULATOR_HEIGHT = int(CALCULATOR_WIDTH*1.5)
        BUTTON_SIZE = (2/13)*CALCULATOR_WIDTH
        BIG_BUTTON_SIZE = (5/13)*CALCULATOR_WIDTH


        keys.config(bg="black")
        keys.title("Num Pad")
        keys.geometry(f"{CALCULATOR_WIDTH}x{CALCULATOR_HEIGHT}")
        keys.resizable(False,False)

        im = PhotoImage(width=1,height=1)

        modulus = Label(keys, text="MODULUS", font=("Calibri", "20", "bold italic"), fg="white", bg="black")
        modulus.place(x=CALCULATOR_WIDTH*2/3, y=40, anchor='center')

        numLock = Button(keys, text="Num\nLock", image=im, compound='c', command=lambda: self.AddNote(10))
        numLock.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        numLock.place(x=(2/13)*CALCULATOR_WIDTH, y=110, anchor='center')

        
        slash = Button(keys, text="/", image=im, compound='c', command=lambda: self.AddNote(11))
        slash.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        slash.place(x=(5/13)*CALCULATOR_WIDTH, y=110, anchor='center')

        star = Button(keys, text="*", image=im, compound='c', command=lambda: self.AddNote(12))
        star.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        star.place(x=(8/13)*CALCULATOR_WIDTH, y=110, anchor='center')

        minus = Button(keys, text="-", image=im, compound='c', command=self.DecreaseOctave)
        minus.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        minus.place(x=(11/13)*CALCULATOR_WIDTH, y=110, anchor='center')


        seven = Button(keys, text="7", image=im, compound='c', command=lambda: self.AddNote(7))
        seven.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        seven.place(x=(2/13)*CALCULATOR_WIDTH, y=170, anchor='center')


        eight = Button(keys, text="8", image=im, compound='c', command=lambda: self.AddNote(8))
        eight.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        eight.place(x=(5/13)*CALCULATOR_WIDTH, y=170, anchor='center')


        nine = Button(keys, text="9", image=im, compound='c', command=lambda: self.AddNote(9))
        nine.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        nine.place(x=(8/13)*CALCULATOR_WIDTH, y=170, anchor="center")


        four = Button(keys, text="4", image=im, compound='c', command=lambda: self.AddNote(4))
        four.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        four.place(x=(2/13)*CALCULATOR_WIDTH, y=230, anchor='center')


        five = Button(keys, text="5", image=im, compound='c', command=lambda: self.AddNote(5))
        five.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        five.place(x=(5/13)*CALCULATOR_WIDTH, y=230, anchor='center')


        six = Button(keys, text="6", image=im, compound='c', command=lambda: self.AddNote(6))
        six.config(height=BUTTON_SIZE,width=BUTTON_SIZE)
        six.place(x=(8/13)*CALCULATOR_WIDTH, y=230, anchor='center')

        one = Button(keys, text="1", image=im, compound='c', command=lambda: self.AddNote(1))
        one.config(height=BUTTON_SIZE, width=BUTTON_SIZE)
        one.place(x=(2/13)*CALCULATOR_WIDTH, y=290, anchor='center')

        two = Button(keys, text="2", image=im, compound='c', command=lambda: self.AddNote(2))
        two.config(height=BUTTON_SIZE, width=BUTTON_SIZE)
        two.place(x=(5/13)*CALCULATOR_WIDTH, y=290, anchor='center')

        three = Button(keys, text="3", image=im, compound='c', command=lambda: self.AddNote(3))
        three.config(height=BUTTON_SIZE, width=BUTTON_SIZE)
        three.place(x=(8/13)*CALCULATOR_WIDTH, y=290, anchor='center')

        plus = Button(keys, text="+", image=im, compound='c', command=self.IncreaseOctave)
        plus.config(height=BIG_BUTTON_SIZE, width=BUTTON_SIZE)
        plus.place(x=(11/13)*CALCULATOR_WIDTH, y=200, anchor='center')


        zero = Button(keys, text="0", image=im, compound='c')
        zero.config(height=BUTTON_SIZE, width=BIG_BUTTON_SIZE)
        zero.place(x=(7/26)*CALCULATOR_WIDTH, y=350, anchor='center')


        period = Button(keys, text=".", image=im, compound='c')
        period.config(height=BUTTON_SIZE, width=BUTTON_SIZE)
        period.place(x=(8/13)*CALCULATOR_WIDTH, y=350, anchor='center')

        enter = Button(keys, text="Enter", image=im, compound='c')
        enter.config(height=BIG_BUTTON_SIZE,width=BUTTON_SIZE)
        enter.place(x=(11/13)*CALCULATOR_WIDTH, y=320, anchor='center')

        keys.mainloop()



    
    def ValidOctave(self):
        """
        Checks to make sure the user has entered an appropriate octave value

        Parameters:
        self (object): the instance of the GUI program

        Returns:
        None
        """
        try:
            if self.octave.getNumber() < 0:
                self.messageBox(title="ERROR", message="Octave must be between 0 and 8")
            if self.octave.getNumber() > 8:
                self.messageBox(title="ERROR", message="Octave must be between 0 and 8")
        except:
            self.messageBox(title="ERROR", message="Octave must be between 0 and 8")


    def AddNote(self, number):
        """
        Adds a midi note to the text file

        Parameters:
        self (object): the instance of the GUI program
        number (int): a number ranging from 1 to 12 representing each of
                      the keys on one octave of a keyboard

        Returns:
        None
        """

        # checking to make sure the user has actually started recording
        if self.record["state"] == "disabled":
            # giving the user an error message if he or she has entered an invalid octave
            self.ValidOctave()
            # an issue occurred trying to get the ValidOctave method to return a true or false value
            # thus it is needed again here to add in the note to the text file if the octave is indeed valid
            try:
                if self.octave.getNumber() >= 0:
                    if self.octave.getNumber() <= 8:
                        self.text += "\n"
                        self.text += str(number + (self.octave.getNumber()*12))
            except:
                pass
        
    def Record(self):
        # adding the instrument choice to the text file
        self.file.write(self.group.getSelectedButton()['text'])
        # disabling the record button
        self.record["state"] = "disabled"
        # enabling the stop recording button
        self.stopRecording["state"] = "normal"

    def StopRecording(self):
        # whatever notes the user has entered will now be added to the text file
        self.file.write(self.text)
        # closing the text file
        self.file.close()
        # disabling the stop recording button
        self.stopRecording["state"] = "disabled"
        # enabling the record button
        self.record["state"] = "normal"

            
    def IncreaseOctave(self):
        try:
            if self.octave.getNumber() < 8:
                self.octave.setNumber(self.octave.getNumber() + 1)
        except:
            self.messageBox(title="ERROR", message="Octave must be between 0 and 8")

    def DecreaseOctave(self):
        try:
            if self.octave.getNumber() > 0:
                self.octave.setNumber(self.octave.getNumber() - 1)
        except:
            self.messageBox(title="ERROR", message="Octave must be between 0 and 8")
        

def main():
    ModulusSoundMachine().mainloop()




if __name__ == "__main__":
    main()

